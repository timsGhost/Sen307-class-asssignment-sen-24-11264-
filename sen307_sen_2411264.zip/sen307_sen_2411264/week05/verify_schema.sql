-- Week 5 Part 4: verify the schema (take a screenshot of each result)
USE sen307_sen_2411264;

SHOW TABLES;
DESCRIBE Department;
DESCRIBE Lecturer;
DESCRIBE Student;
DESCRIBE Course;
DESCRIBE Enrolment;
DESCRIBE CourseAllocation;
SHOW CREATE TABLE Enrolment;
