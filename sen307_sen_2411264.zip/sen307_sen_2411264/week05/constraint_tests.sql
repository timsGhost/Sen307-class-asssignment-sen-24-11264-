-- Week 5 Part 3: every statement below breaks a rule ON PURPOSE and must fail.
-- Run ONE AT A TIME in Workbench (select the line, press Ctrl+Enter),
-- or run the whole file with the mysql command-line using --force (run_all.bat does this).
USE sen307_sen_2411264;

-- Test 1: NOT NULL (should fail: dept_name is required)
INSERT INTO Department (dept_name) VALUES (NULL);

-- Test 2: CHECK (should fail: credit_units must be 1 to 6)
INSERT INTO Course (course_code, course_title, credit_units) VALUES ('TST101', 'Test', 9);

-- Test 3: FOREIGN KEY (should fail: department 999 does not exist)
INSERT INTO Student (matric_no, full_name, dept_id) VALUES ('TEST001', 'Test', 999);

-- Test 4: ENUM (should fail: gender must be 'M' or 'F')
INSERT INTO Student (matric_no, full_name, gender) VALUES ('TEST002', 'Test', 'X');

-- Confirm every table is still empty (all should show 0)
SELECT COUNT(*) FROM Department;
SELECT COUNT(*) FROM Course;
SELECT COUNT(*) FROM Student;

-- ---------------------------------------------------------------
-- YOUR TURN: break the UNIQUE constraint on Department.dept_name
-- The 1st insert succeeds, the 2nd must fail with Error 1062 (Duplicate entry)
-- ---------------------------------------------------------------
INSERT INTO Department (dept_name) VALUES ('Test Department');
INSERT INTO Department (dept_name) VALUES ('Test Department');   -- <-- fails (UNIQUE)

-- Clean up so Week 6 starts with an empty table
SET SQL_SAFE_UPDATES = 0;
DELETE FROM Department WHERE dept_name = 'Test Department';
SET SQL_SAFE_UPDATES = 1;

SELECT COUNT(*) AS departments_left FROM Department;
