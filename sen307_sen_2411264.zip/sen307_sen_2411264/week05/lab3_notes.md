# Lab 3 Notes: DDL and Constraint Testing (Week 5)

**Matric:** sen_2411264  |  **Database:** `sen307_sen_2411264`

## Constraint tests (each statement failed, so no rows were saved)

> These messages were captured from a real run on MySQL 8.0. If the wording in *your* Workbench
> Action Output differs slightly, replace it with yours.

| Test | Rule broken | Error message |
| --- | --- | --- |
| 1 | NOT NULL (`dept_name`) | `Error Code: 1048. Column 'dept_name' cannot be null` |
| 2 | CHECK (`credit_units` 1 to 6) | `Error Code: 3819. Check constraint 'chk_credit_units' is violated.` |
| 3 | FOREIGN KEY (department 999) | `Error Code: 1452. Cannot add or update a child row: a foreign key constraint fails (...Student, CONSTRAINT Student_ibfk_1 FOREIGN KEY (dept_id) REFERENCES Department (dept_id))` |
| 4 | ENUM (`gender` = 'X') | `Error Code: 1265. Data truncated for column 'gender' at row 1` |
| **My own test** | UNIQUE (`Department.dept_name`) | `Error Code: 1062. Duplicate entry 'Test Department' for key 'Department.dept_name'` |

After the tests, `SELECT COUNT(*)` returned **0** for Department, Course and Student, so no bad rows were stored.

**My own UNIQUE test:** I inserted `'Test Department'` twice into `Department`. The first insert worked, the second was rejected with Error 1062 because `dept_name` is `UNIQUE`. I then removed the test row with `DELETE FROM Department WHERE dept_name = 'Test Department';`.

## Reverse-engineered diagram vs my Week 4 diagram

The reverse-engineered diagram (`lab3_erd.png`) matches the Week 4 design: six tables, with Enrolment and CourseAllocation acting as junction tables. It differs in that it shows the real data types, the `phone` column added by `ALTER TABLE`, the `UNIQUE`/`NOT NULL` flags and the foreign-key names MySQL generated (e.g. `Student_ibfk_1`), none of which were on my hand-drawn design. The `CHECK` constraint is not drawn on the diagram at all, even though it exists in the database.
