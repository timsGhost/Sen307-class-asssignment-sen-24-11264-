-- Week 4 recap / setup check
-- (CREATE DATABASE line added so this works even if your Week 3 database is missing)
CREATE DATABASE IF NOT EXISTS sen307_sen_2411264;

SHOW DATABASES;

USE sen307_sen_2411264;

SELECT DATABASE();
