# VUA-SEN307 Lab 2: Database Design and Normalization to 3NF

**Student matric:** sen_2411264  |  **Database:** `sen307_sen_2411264`

---

## Part 1: Entities, attributes and relationships

### Step 1: Entities and attributes

| Entity | Attributes | Primary key |
| --- | --- | --- |
| **Department** | dept_id, dept_name | dept_id |
| **Student** | student_id, matric_no, full_name, phone, gender, date_of_birth, dept_id | student_id |
| **Lecturer** | lecturer_id, staff_no, full_name, email, dept_id | lecturer_id |
| **Course** | course_id, course_code, course_title, credit_units, description, dept_id | course_id |
| **Enrolment** | enrolment_id, student_id, course_id, academic_session, semester, enrolled_on | enrolment_id |
| **CourseAllocation** (junction) | allocation_id, course_id, lecturer_id, academic_session | allocation_id |

### Step 2: Relationships and cardinalities

| Question | Answer |
| --- | --- |
| Departments per student? | **One** (a student belongs to exactly one department). |
| Students per department? | **Many**. Department 1 : N Student. |
| Courses per student? | **Many** in a semester. |
| Students per course? | **Many**. Student M : N Course, resolved by the **Enrolment** table. |
| Lecturers per course (across sessions)? | **Many**. |
| Courses per lecturer? | **Many**. Course M : N Lecturer, resolved by the **CourseAllocation** table. |
| Lecturers per department / courses per department | **Many**. Department 1 : N Lecturer and Department 1 : N Course. |

The design has **two many-to-many relationships** (Student-Course and Course-Lecturer). Each needs its own junction table, which is why the final design has six tables, not five.

---

## Part 2: Normalization

### Unnormalized registration sheet

| matric_no | student_name | student_dept | course_codes | course_titles | lecturers | lecturer_depts | session |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20231234 | Ada Obi | Software Engineering | SEN307, SEN301 | Database Systems, Software Architecture | Dr A. Okafor, Dr M. Bello | Software Eng., Software Eng. | 2026/2027 |
| 20231235 | John Musa | Computer Science | SEN307, COS301 | Database Systems, Operating Systems | Dr A. Okafor, Mrs F. Eze | Software Eng., Computer Sci. | 2026/2027 |
| 20231236 | Grace Okon | Software Engineering | SEN301 | Software Architecture | Dr M. Bello | Software Eng. | 2026/2027 |

### Step 1: First Normal Form (1NF)

Each student-course pair gets its own row. **Primary key: (matric_no, course_code)**, because no single column is unique on its own.

| matric_no | student_name | student_dept | course_code | course_title | lecturer | lecturer_dept | session |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 20231234 | Ada Obi | Software Engineering | SEN307 | Database Systems | Dr A. Okafor | Software Eng. | 2026/2027 |
| 20231234 | Ada Obi | Software Engineering | SEN301 | Software Architecture | Dr M. Bello | Software Eng. | 2026/2027 |
| 20231235 | John Musa | Computer Science | SEN307 | Database Systems | Dr A. Okafor | Software Eng. | 2026/2027 |
| 20231235 | John Musa | Computer Science | COS301 | Operating Systems | Mrs F. Eze | Computer Sci. | 2026/2027 |
| 20231236 | Grace Okon | Software Engineering | SEN301 | Software Architecture | Dr M. Bello | Software Eng. | 2026/2027 |

**What I fixed:** I removed the multi-valued cells (comma-separated lists) so that every cell holds exactly one value.

### Step 2: Second Normal Form (2NF)

Partial dependencies on the composite key (matric_no, course_code):

* `student_name`, `student_dept` depend only on **matric_no**.
* `course_title`, `lecturer`, `lecturer_dept` depend only on **course_code**.
* `session` depends on the **whole** key (the registration itself).

**Student**(matric_no PK, student_name, student_dept)

| matric_no | student_name | student_dept |
| --- | --- | --- |
| 20231234 | Ada Obi | Software Engineering |
| 20231235 | John Musa | Computer Science |
| 20231236 | Grace Okon | Software Engineering |

**Course**(course_code PK, course_title, lecturer, lecturer_dept)

| course_code | course_title | lecturer | lecturer_dept |
| --- | --- | --- | --- |
| SEN307 | Database Systems | Dr A. Okafor | Software Eng. |
| SEN301 | Software Architecture | Dr M. Bello | Software Eng. |
| COS301 | Operating Systems | Mrs F. Eze | Computer Sci. |

**Enrolment**(matric_no PK/FK, course_code PK/FK, session)

| matric_no | course_code | session |
| --- | --- | --- |
| 20231234 | SEN307 | 2026/2027 |
| 20231234 | SEN301 | 2026/2027 |
| 20231235 | SEN307 | 2026/2027 |
| 20231235 | COS301 | 2026/2027 |
| 20231236 | SEN301 | 2026/2027 |

**What I fixed:** I moved every attribute that depended on only part of the key into its own table, giving Student, Course and Enrolment.

### Step 3: Third Normal Form (3NF)

Transitive dependencies (a non-key column depending on another non-key column):

* `student_dept` describes a **department**, not the student. If "Software Engineering" were renamed, every student row would have to be edited (an update anomaly).
* `lecturer_dept` depends on the **lecturer**, not on the course.
* *Which lecturer teaches which course in which session* is a many-to-many fact, so it gets its own table (**CourseAllocation**) instead of sitting inside Course.

**Department**

| dept_id | dept_name |
| --- | --- |
| 1 | Software Engineering |
| 2 | Computer Science |

**Lecturer**

| lecturer_id | full_name | dept_id |
| --- | --- | --- |
| 1 | Dr A. Okafor | 1 |
| 2 | Dr M. Bello | 1 |
| 3 | Mrs F. Eze | 2 |

**Student**

| student_id | matric_no | full_name | dept_id |
| --- | --- | --- | --- |
| 1 | 20231234 | Ada Obi | 1 |
| 2 | 20231235 | John Musa | 2 |
| 3 | 20231236 | Grace Okon | 1 |

**Course**

| course_id | course_code | course_title | dept_id |
| --- | --- | --- | --- |
| 1 | SEN307 | Database Systems | 1 |
| 2 | SEN301 | Software Architecture | 1 |
| 3 | COS301 | Operating Systems | 2 |

**Enrolment**

| enrolment_id | student_id | course_id | academic_session |
| --- | --- | --- | --- |
| 1 | 1 | 1 | 2026/2027 |
| 2 | 1 | 2 | 2026/2027 |
| 3 | 2 | 1 | 2026/2027 |
| 4 | 2 | 3 | 2026/2027 |
| 5 | 3 | 2 | 2026/2027 |

**CourseAllocation**

| allocation_id | course_id | lecturer_id | academic_session |
| --- | --- | --- | --- |
| 1 | 1 | 1 | 2026/2027 |
| 2 | 2 | 2 | 2026/2027 |
| 3 | 3 | 3 | 2026/2027 |

**What I fixed:** I removed the transitive dependencies by moving department details into **Department** and lecturer details into **Lecturer**, linked by foreign keys, so each fact is stored once.

### Step 4: Final schema

```
Department       (dept_id PK, dept_name UNIQUE)
Lecturer         (lecturer_id PK, staff_no UNIQUE, full_name, email UNIQUE, dept_id FK -> Department)
Student          (student_id PK, matric_no UNIQUE, full_name, phone, gender, date_of_birth, dept_id FK -> Department)
Course           (course_id PK, course_code UNIQUE, course_title, credit_units, description, dept_id FK -> Department)
Enrolment        (enrolment_id PK, student_id FK -> Student, course_id FK -> Course,
                  academic_session, semester, enrolled_on;  UNIQUE(student_id, course_id, academic_session))
CourseAllocation (allocation_id PK, course_id FK -> Course, lecturer_id FK -> Lecturer,
                  academic_session;  UNIQUE(course_id, lecturer_id, academic_session))
```
