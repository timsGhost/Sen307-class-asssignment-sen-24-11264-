-- VUA-SEN307 Week 6 (Lab 4): DML - Insert, Update, Delete
-- Matric: sen_2411264
-- Safe to re-run: the reset block below empties the tables first so IDs always start at 1.

USE sen307_sen_2411264;

-- ---------- reset block (so the script can be run again cleanly) ----------
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE CourseAllocation;
TRUNCATE TABLE Enrolment;
TRUNCATE TABLE Student;
TRUNCATE TABLE Lecturer;
TRUNCATE TABLE Course;
TRUNCATE TABLE Department;
SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- PART 1: Departments and Courses (provided)
-- =====================================================================
INSERT INTO Department (dept_name) VALUES
('Software Engineering'),
('Computer Science'),
('Artificial Intelligence'),
('Data Science'),
('Cybersecurity');

INSERT INTO Course (course_code, course_title, credit_units, description, dept_id) VALUES
('SEN307', 'Database Systems', 3,
 'Relational database design, SQL queries, normalization, transactions and indexing using MySQL.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),
('SEN301', 'Software Architecture', 3,
 'Architectural styles, design patterns, microservices and how to structure large software systems.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),
('COS301', 'Operating Systems', 3,
 'Processes, threads, CPU scheduling, memory management and file systems.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),
('COS305', 'Computer Networks', 3,
 'TCP/IP, routing, switching, LAN and WAN design and network protocols.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),
('AIN301', 'Introduction to Artificial Intelligence', 3,
 'Intelligent agents, search algorithms, knowledge representation and reasoning.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),
('AIN305', 'Machine Learning', 3,
 'Supervised and unsupervised learning, neural networks, deep learning and model evaluation.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),
('AIN307', 'Natural Language Processing', 3,
 'Text processing, word embeddings, language models, sentiment analysis and chatbots.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),
('DTS301', 'Data Visualization and Analytics', 2,
 'Exploratory data analysis, charts, dashboards and telling stories with data.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),
('DTS305', 'Big Data Technologies', 3,
 'Distributed storage and processing of very large datasets with Hadoop and Spark.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),
('CYB301', 'Network Security', 3,
 'Firewalls, cryptography, intrusion detection and protecting networks from attacks.',
 (SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity'));

-- Should list 5 departments with 10 courses between them
SELECT d.dept_name, COUNT(c.course_id) AS courses
FROM Department d LEFT JOIN Course c ON d.dept_id = c.dept_id
GROUP BY d.dept_name;

SELECT dept_id, dept_name FROM Department;
SELECT course_id, course_code FROM Course;

-- =====================================================================
-- PART 2: Your own data
-- =====================================================================

-- Step 1: Lecturers (10 in total, 2 per department)
INSERT INTO Lecturer (staff_no, full_name, email, dept_id) VALUES
('VUA/ST/101', 'Dr Amaka Okafor',      'a.okafor@vua.edu.ng',    1),
('VUA/ST/102', 'Dr Musa Bello',        'm.bello@vua.edu.ng',     1),
('VUA/ST/103', 'Mrs Funke Eze',        'f.eze@vua.edu.ng',       2),
('VUA/ST/104', 'Dr Chinedu Nwosu',     'c.nwosu@vua.edu.ng',     2),
('VUA/ST/105', 'Prof Ibrahim Danjuma', 'i.danjuma@vua.edu.ng',   3),
('VUA/ST/106', 'Dr Ngozi Adeyemi',     'n.adeyemi@vua.edu.ng',   3),
('VUA/ST/107', 'Dr Emeka Obiora',      'e.obiora@vua.edu.ng',    4),
('VUA/ST/108', 'Mrs Halima Suleiman',  'h.suleiman@vua.edu.ng',  4),
('VUA/ST/109', 'Dr Tunde Fashola',     't.fashola@vua.edu.ng',   5),
('VUA/ST/110', 'Dr Blessing Eteng',    'b.eteng@vua.edu.ng',     5);

-- Step 2: Students (20 in total). Student 1 is YOU.
-- >>> Change 'Nden' to your full name, and fill in your gender / date of birth if you like. <<<
INSERT INTO Student (matric_no, full_name, gender, date_of_birth, dept_id) VALUES
('sen_2411264', 'Nden',             NULL, NULL,         1),
('sen_2411201', 'John Musa',        'M', '2004-11-02', 2),
('sen_2411202', 'Grace Okon',       'F', '2005-06-21', 1),
('sen_2411203', 'Chidi Eze',        'M', '2003-09-09', 3),
('sen_2411204', 'Aisha Abdullahi',  'F', '2004-02-17', 3),
('sen_2411205', 'Tobi Adebayo',     'M', '2006-01-30', 4),
('sen_2411206', 'Ngozi Nwankwo',    'F', '2005-08-12', 1),
('sen_2411207', 'Emeka Okeke',      'M', '2003-12-05', 5),
('sen_2411208', 'Fatima Yusuf',     'F', '2006-04-25', 2),
('sen_2411209', 'Samuel Etim',      'M', '2004-07-19', 1),
('sen_2411210', 'Blessing Udoh',    'F', '2007-02-08', 4),
('sen_2411211', 'Ibrahim Lawal',    'M', '2005-10-03', 5),
('sen_2411212', 'Zainab Bello',     'F', '2004-05-27', 3),
('sen_2411213', 'Oluwaseun Ajayi',  'M', '2006-09-14', 2),
('sen_2411214', 'Hauwa Garba',      'F', '2003-03-22', 1),
('sen_2411215', 'Kelechi Obi',      'M', '2007-06-11', 3),
('sen_2411216', 'Mercy Ibe',        'F', '2005-12-29', 4),
('sen_2411217', 'David Ekong',      'M', '2004-01-15', 5),
('sen_2411218', 'Peace Okoro',      'F', '2006-11-06', 2),
('sen_2411219', 'Yakubu Danladi',   'M', '2003-08-31', 1);

SELECT student_id, matric_no, full_name FROM Student;
SELECT lecturer_id, full_name FROM Lecturer;

-- Step 3: Enrolments (40 in total). Students 19 and 20 are deliberately NOT enrolled.
-- Course 1 (SEN307) ends up with 7 students.
INSERT INTO Enrolment (student_id, course_id) VALUES
(1,1),(1,2),
(2,1),(2,3),
(3,1),(3,2),(3,4),
(4,5),(4,6),
(5,5),(5,7),
(6,8),(6,9),
(7,1),(7,2),
(8,10),(8,4),
(9,3),(9,4),
(10,1),(10,2),(10,6),
(11,8),(11,6),
(12,10),(12,9),(12,3),
(13,5),(13,6),(13,7),
(14,3),(14,1),
(15,1),(15,2),
(16,6),(16,7),
(17,8),(17,9),
(18,10),(18,4);

-- Course allocations (12 rows): every course has a lecturer; course 1 has TWO lecturers
INSERT INTO CourseAllocation (course_id, lecturer_id) VALUES
(1,1),(1,2),
(2,2),
(3,3),
(4,4),
(5,5),
(6,6),
(7,5),
(8,7),
(9,8),
(10,9),(10,10);

-- =====================================================================
-- PART 3: UPDATE a record (move yourself to Computer Science)
-- =====================================================================
SELECT matric_no, full_name, dept_id FROM Student WHERE matric_no = 'sen_2411264';

SET SQL_SAFE_UPDATES = 0;
UPDATE Student SET dept_id = 2 WHERE matric_no = 'sen_2411264';
SET SQL_SAFE_UPDATES = 1;

SELECT matric_no, full_name, dept_id FROM Student WHERE matric_no = 'sen_2411264';

-- =====================================================================
-- PART 4: Referential integrity
-- =====================================================================

-- Step 1: create a department with a student in it
INSERT INTO Department (dept_name) VALUES ('Library and Information Science');

INSERT INTO Student (matric_no, full_name, dept_id)
VALUES ('20239999', 'Transfer Student',
        (SELECT dept_id FROM Department WHERE dept_name = 'Library and Information Science'));

-- Step 2: try to delete the department -> Error 1451 (foreign key constraint fails).
-- This line is COMMENTED OUT so the whole script can run without stopping.
-- To get your screenshot: select ONLY this line in Workbench, remove the '-- ' and press Ctrl+Enter.
-- (Or just run the file week06/error1451_demo.sql)
-- DELETE FROM Department WHERE dept_name = 'Library and Information Science';

-- Step 3: fix it the correct way
-- 3a: reassign the dependent student to another department
SET SQL_SAFE_UPDATES = 0;
UPDATE Student
SET dept_id = (SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')
WHERE matric_no = '20239999';

-- 3b: now the delete succeeds
DELETE FROM Department WHERE dept_name = 'Library and Information Science';
SET SQL_SAFE_UPDATES = 1;

SELECT * FROM Department;

-- =====================================================================
-- FINAL CHECK (screenshot this result)
-- =====================================================================
SELECT 'Departments' AS tbl, COUNT(*) AS total FROM Department
UNION ALL SELECT 'Lecturers',   COUNT(*) FROM Lecturer
UNION ALL SELECT 'Students',    COUNT(*) FROM Student
UNION ALL SELECT 'Courses',     COUNT(*) FROM Course
UNION ALL SELECT 'Enrolments',  COUNT(*) FROM Enrolment
UNION ALL SELECT 'Allocations', COUNT(*) FROM CourseAllocation;
