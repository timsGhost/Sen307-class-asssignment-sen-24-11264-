-- Week 6 Part 4, Step 2: this is SUPPOSED to fail with Error 1451.
-- Run it ONLY while a student still belongs to 'Library and Information Science'
-- i.e. after Step 1 of Part 4 and before Step 3 (the fix).
-- Easiest way to use it: in Workbench run data.sql up to the Step 1 inserts, then run this, screenshot the error.
USE sen307_sen_2411264;

DELETE FROM Department WHERE dept_name = 'Library and Information Science';
