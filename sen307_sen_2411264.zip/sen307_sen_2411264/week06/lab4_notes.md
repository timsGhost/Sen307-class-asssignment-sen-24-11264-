# Lab 4 Notes: Referential Integrity (Week 6)

**Matric:** sen_2411264

**Error received:** When I ran `DELETE FROM Department WHERE dept_name = 'Library and Information Science';`, MySQL returned **Error 1451: Cannot delete or update a parent row: a foreign key constraint fails**.

**Why MySQL refuses:** `Student.dept_id` is a foreign key that references `Department.dept_id`. The student "Transfer Student" (20239999) still pointed to that department, so deleting the department would have left a student with a `dept_id` that no longer exists (an orphan row). MySQL enforces referential integrity, so it blocks the delete instead of letting the data become inconsistent.

**How I fixed it:** I first ran an `UPDATE` to reassign the dependent student to the Software Engineering department, so that no child row referenced the department any more. After that, the `DELETE` succeeded and the table was back to 5 departments. The student was moved, not lost.

**Other ways I could have fixed it:**
1. Delete the dependent student row(s) first, then delete the department (this loses the student's record).
2. Define the foreign key with `ON DELETE SET NULL` (possible because `Student.dept_id` allows NULL), so deleting a department automatically sets its students' `dept_id` to NULL.
3. Define the foreign key with `ON DELETE CASCADE`, which automatically deletes the students too. This is risky because it can silently remove a lot of data.
