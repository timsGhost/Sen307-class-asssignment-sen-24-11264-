# SEN307 Labs: Weeks 4, 5, 6  (matric: sen_2411264)

Database name used everywhere: **`sen307_sen_2411264`**

```
sen307_sen_2411264/
  README.md                  <- this file
  run_all.bat                <- one-click runner (Windows), no Workbench needed
  reset_database.sql         <- wipes the database and starts over
  week04/  setup_check.sql, lab2_normalization.md
  week05/  schema.sql, constraint_tests.sql, verify_schema.sql, lab3_notes.md
  week06/  data.sql, error1451_demo.sql, lab4_notes.md
```

## Before you start: edit one thing
Open `week06/data.sql`, find the line `('sen_2411264', 'Nden', NULL, NULL, 1)` and change `'Nden'` to your full name
(and optionally put your gender `'M'`/`'F'` and date of birth `'2005-01-31'` in place of the two `NULL`s).

## Option A: MySQL Workbench (what the lab expects)
1. Open Workbench and click your connection tile (**localhost1** / Level 1 Connection). Enter the root password.
2. **File > Open SQL Script...** and pick the file, then run the **whole** script with **Ctrl+Shift+Enter** (lightning bolt).
   Every script already has `USE sen307_sen_2411264;` at the top. Week 4 and 5 also create the database if it is missing.
3. Run them in this order:

| Order | File | How to run | What to capture |
| --- | --- | --- | --- |
| 1 | `week04/setup_check.sql` | whole script | nothing |
| 2 | `week05/schema.sql` | whole script | nothing |
| 3 | `week05/constraint_tests.sql` | **one statement at a time**: click on the line, press **Ctrl+Enter**. Each INSERT should fail. | copy each error message from the Action Output (already filled in `lab3_notes.md`) |
| 4 | `week05/verify_schema.sql` | whole script | screenshot each DESCRIBE result |
| 5 | `week06/data.sql` | whole script | screenshot the last result (final counts) |
| 6 | Error 1451 | see below | screenshot of the error |

**Error 1451 screenshot:** run `week06/data.sql` once, then run these two lines on their own (the department then has a student in it):
```sql
INSERT INTO Department (dept_name) VALUES ('Library and Information Science');
INSERT INTO Student (matric_no, full_name, dept_id) VALUES ('20230001','Temp Student',
   (SELECT dept_id FROM Department WHERE dept_name='Library and Information Science'));
DELETE FROM Department WHERE dept_name = 'Library and Information Science';   -- <- Error 1451, screenshot this
```
Then re-run `week06/data.sql`; it resets and rebuilds everything cleanly.

## Option B: One-click runner (no Workbench)
Double-click **`run_all.bat`**. It finds `mysql.exe` (MySQL Server or XAMPP), asks for host/port/user/password
(defaults: 127.0.0.1, 3306, root), then runs Weeks 4 to 6 in order and prints the results.

## The EER diagram files (Week 4 and Week 5 submissions)
These must come from Workbench, so do this after running `schema.sql`:
1. **Database > Reverse Engineer...** > pick your connection > tick `sen307_sen_2411264` > Next... > Finish.
2. Arrange the tables so lines do not cross. Check that the PK (key) and FK (red diamond) icons show.
3. **File > Save Model As...** > `lab2_model.mwb` (put it in `week04/`).
4. **File > Export > Export as PNG...** > `lab2_erd.png` (in `week04/`), and save a copy as `lab3_erd.png` (in `week05/`).
   (Week 4 asks you to build the diagram by hand with *File > New Model*; the reverse-engineer route gives the same six tables
   faster, but build it by hand if you want to practise.)

## Save your screenshots and push to GitHub
```
cd sen307-labs
mkdir week04 week05 week06
:: copy the three week folders' contents + screenshots + .mwb/.png into them, then:
git add .
git commit -m "Weeks 4-6: ER diagram, DDL schema, DML data"
git push
```
(The handout uses one commit per week; do `git add . / git commit / git push` after each week's folder if you prefer.)

## Troubleshooting
| Message | Fix |
| --- | --- |
| `Error 1175 safe update mode` | Already handled with `SET SQL_SAFE_UPDATES = 0/1` inside the scripts. |
| `Error 1046 No database selected` | Run the `USE sen307_sen_2411264;` line first (it is at the top of every script). |
| `Error 1050 Table already exists` | You ran `schema.sql` twice. Run `reset_database.sql`, then `schema.sql` again. |
| `Error 1045 Access denied` | Wrong root password for that connection. |
| `Error 2003 Can't connect` | The MySQL server is not running. Start the MySQL service (services.msc), or XAMPP's MySQL. |
| `Error 1064` near `CHECK` / `DEFAULT (CURRENT_DATE)` | Your server is too old: needs MySQL 8.0.16+ or MariaDB 10.2.1+. |
