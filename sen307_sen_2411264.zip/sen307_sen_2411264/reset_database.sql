-- Start completely fresh (only use this if you want to wipe everything and redo the labs)
DROP DATABASE IF EXISTS sen307_sen_2411264;
CREATE DATABASE sen307_sen_2411264;
USE sen307_sen_2411264;
SELECT DATABASE();
