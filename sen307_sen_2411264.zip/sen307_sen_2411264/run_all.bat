@echo off
setlocal
title SEN307 Lab Runner - sen_2411264
cd /d "%~dp0"

rem ---- find mysql.exe ----
set "MYSQLEXE="
where mysql >nul 2>nul
if not errorlevel 1 set "MYSQLEXE=mysql"
if not defined MYSQLEXE (
  for /d %%D in ("C:\Program Files\MySQL\MySQL Server *") do (
    if exist "%%~D\bin\mysql.exe" set "MYSQLEXE=%%~D\bin\mysql.exe"
  )
)
if not defined MYSQLEXE (
  if exist "C:\xampp\mysql\bin\mysql.exe" set "MYSQLEXE=C:\xampp\mysql\bin\mysql.exe"
)
if not defined MYSQLEXE (
  echo Could not find mysql.exe automatically.
  set /p MYSQLEXE=Paste the full path to mysql.exe: 
)
echo Using: %MYSQLEXE%
echo.

rem ---- connection details (press Enter to accept the default in brackets) ----
set "DBHOST=127.0.0.1"
set /p DBHOST=Host [127.0.0.1]: 
set "DBPORT=3306"
set /p DBPORT=Port [3306]: 
set "DBUSER=root"
set /p DBUSER=User [root]: 
set "MYSQL_PWD="
set /p MYSQL_PWD=Password (press Enter if none): 

echo.
echo  1 = Run EVERYTHING from scratch (drops and recreates database sen307_sen_2411264)
echo  2 = Run only Week 6 data (tables must already exist)
echo  3 = Quit
set "CH=3"
set /p CH=Choose 1, 2 or 3: 
if "%CH%"=="1" goto all
if "%CH%"=="2" goto week6
goto done

:all
echo.
echo ===== Reset database =====
call :run "reset_database.sql"
echo.
echo ===== Week 4: setup check =====
call :run "week04\setup_check.sql"
echo.
echo ===== Week 5: create tables =====
call :run "week05\schema.sql"
echo.
echo ===== Week 5: constraint tests (errors below are EXPECTED) =====
call :run "week05\constraint_tests.sql" --force
echo.
echo ===== Week 5: verify schema =====
call :run "week05\verify_schema.sql"

:week6
echo.
echo ===== Week 6: insert / update / delete data =====
call :run "week06\data.sql"
echo.
echo All done. Open MySQL Workbench to see the data, then take your screenshots.
goto done

:run
"%MYSQLEXE%" -h %DBHOST% -P %DBPORT% -u %DBUSER% --table %2 < "%~1"
if errorlevel 1 echo [!] The step above reported an error. Read the message.
exit /b

:done
echo.
pause
